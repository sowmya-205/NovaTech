import { createContext, useContext, useMemo, useState } from 'react'
import { products } from '../data/products'
const StoreContext = createContext(null)
export function StoreProvider({ children }) {
  const [cart, setCart] = useState([{ id: 1, qty: 1 }, { id: 2, qty: 1 }])
  const [orders, setOrders] = useState([{ id: 'NT1245678', date: '17 Nov 2026', status: 'Shipped', total: 4999, productId: 1 }])
  const addToCart = (id, qty = 1) => setCart(old => {
    const found = old.find(x => x.id === id)
    return found ? old.map(x => x.id === id ? { ...x, qty: x.qty + qty } : x) : [...old, { id, qty }]
  })
  const changeQty = (id, delta) => setCart(old => old.map(x => x.id === id ? { ...x, qty: x.qty + delta } : x).filter(x => x.qty > 0))
  const removeFromCart = id => setCart(old => old.filter(x => x.id !== id))
  const clearCart = () => setCart([])
  const cartItems = useMemo(() => cart.map(row => ({ ...row, product: products.find(p => p.id === row.id) })).filter(x => x.product), [cart])
  const count = cart.reduce((n, x) => n + x.qty, 0)
  const subtotal = cartItems.reduce((n, x) => n + x.product.price * x.qty, 0)
  const discount = subtotal >= 10000 ? 1000 : 0
  const total = subtotal - discount
  const placeOrder = () => {
    const id = `NT${Math.floor(1000000 + Math.random() * 8999999)}`
    setOrders(old => [{ id, date: '17 Nov 2026', status: 'Processing', total, productId: cartItems[0]?.id || 1 }, ...old])
    clearCart()
    return id
  }
  return <StoreContext.Provider value={{ cart, cartItems, count, subtotal, discount, total, orders, addToCart, changeQty, removeFromCart, clearCart, placeOrder }}>{children}</StoreContext.Provider>
}
export const useStore = () => useContext(StoreContext)