import { useState } from 'react'
import { Link, NavLink, useNavigate } from 'react-router-dom'
import { Search, ShoppingCart, UserRound, Menu, X, Cpu } from 'lucide-react'
import { useStore } from '../store/StoreContext'
export default function Header() {
 const { count } = useStore(), [query,setQuery] = useState(''), [open,setOpen] = useState(false), navigate = useNavigate()
 const search = e => { e.preventDefault(); navigate(`/products${query ? `?search=${encodeURIComponent(query)}` : ''}`); setOpen(false) }
 return <header className="header"><Link to="/" className="logo"><span className="logo-mark">N</span><span>NovaTech</span></Link>
 <button className="mobile-menu" onClick={()=>setOpen(!open)} aria-label="Toggle menu">{open?<X/>:<Menu/>}</button>
 <nav className={open?'nav open':'nav'}><NavLink to="/">Home</NavLink><NavLink to="/products">Products</NavLink><NavLink to="/orders">Orders</NavLink><NavLink to="/assistant">AI Assistant</NavLink></nav>
 <div className="header-actions"><form className="searchbox" onSubmit={search}><Search size={16}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search products, brands..."/></form><button className="header-icon" onClick={()=>navigate('/cart')} aria-label="Shopping cart"><ShoppingCart/><i>{count}</i></button><button className="header-icon" aria-label="Account"><UserRound/></button></div>
 </header>
}