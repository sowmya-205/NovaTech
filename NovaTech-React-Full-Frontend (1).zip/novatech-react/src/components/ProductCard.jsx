import { useState } from 'react'
import { Heart, Star, ShoppingCart } from 'lucide-react'
import { Link } from 'react-router-dom'
import { useStore } from '../store/StoreContext'
export const money = n => '₹'+Number(n||0).toLocaleString('en-IN')
export default function ProductCard({product}){const {addToCart}=useStore(),[liked,setLiked]=useState(false),[added,setAdded]=useState(false)
const add=()=>{addToCart(product.id);setAdded(true);setTimeout(()=>setAdded(false),1100)}
return <article className="product-card"><button className={`wish ${liked?'liked':''}`} onClick={()=>setLiked(!liked)} aria-label="Add to wishlist"><Heart size={18} fill={liked?'currentColor':'none'}/></button><Link to={`/product/${product.id}`} className="product-image"><img src={product.image} alt={product.name}/></Link><div className="product-info"><span className="product-category">{product.category}</span><Link to={`/product/${product.id}`}><h3>{product.name}</h3></Link><div className="price-line"><b>{money(product.price)}</b><del>{money(product.oldPrice)}</del><span className="sale">{product.tag}</span></div><div className="rating"><Star size={14} fill="currentColor"/> {product.rating} <span>({product.reviews.toLocaleString()} reviews)</span></div><button className="btn btn-small btn-primary add-btn" onClick={add}><ShoppingCart size={15}/>{added?'Added to Cart':'Add to Cart'}</button></div></article>
}