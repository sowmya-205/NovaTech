# NovaTech React E-commerce Frontend

A responsive, multi-page B2C storefront recreated from the supplied NovaTech reference design.

## Tech stack
- React 18
- Vite
- React Router DOM
- Context API + React hooks for cart and order state
- Lucide React icons
- Framer Motion dependency included for future motion enhancements
- Custom responsive CSS (no Tailwind setup required)

## Pages
1. Home / browse and discover
2. Product listing / search / category, brand, price and rating filters
3. Product details / quantity / wishlist toggle / add to cart
4. Cart / quantity updates / remove items / totals
5. Checkout / saved address selection / delivery choice / coupon
6. Payment / UPI, card, net banking and COD selection
7. Order confirmation
8. My orders / tracking timeline
9. AI shopping assistant demo

## Run in Kiro or VS Code
Install Node.js LTS first: https://nodejs.org/

Open this folder in Kiro, then open Terminal and run:

```bash
npm install
npm run dev
```

Open the local URL printed by Vite (normally http://localhost:5173).

To make a production build:

```bash
npm run build
npm run preview
```

## Important
This is a frontend project. Cart and order state work in the browser session, but there is no database, authentication, real payment gateway, shipping API, or live AI service connected. Payment is simulated and must not be used to collect real card details. Product images and Google Fonts load from the internet.
